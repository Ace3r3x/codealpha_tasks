// DOM Elements
const ageForm = document.getElementById('ageForm');
const dayInput = document.getElementById('day');
const monthInput = document.getElementById('month');
const yearInput = document.getElementById('year');
const resultDiv = document.getElementById('result');
const yearsDisplay = document.getElementById('years');
const monthsDisplay = document.getElementById('months');
const daysDisplay = document.getElementById('days');
const totalDaysDisplay = document.getElementById('totalDays');
const generalError = document.getElementById('generalError');
const dayError = document.getElementById('dayError');
const monthError = document.getElementById('monthError');
const yearError = document.getElementById('yearError');

// Form submission handler
ageForm.addEventListener('submit', (e) => {
    e.preventDefault();
    clearErrors();
    calculateAge();
});

// Input change handlers for real-time validation
dayInput.addEventListener('input', validateDay);
monthInput.addEventListener('input', () => {
    validateMonth();
    if (dayInput.value) validateDay(); // Re-validate days constraint if month updates
});
yearInput.addEventListener('input', () => {
    validateYear();
    if (dayInput.value && monthInput.value) validateDay(); // Re-validate leap years if day/month exist
});

 // Validates the day input
function validateDay() {
    if (!dayInput.value.trim()) {
        dayError.textContent = 'Day is required';
        dayInput.classList.add('input-error');
        return false;
    }

    const day = parseInt(dayInput.value, 10);
    const month = parseInt(monthInput.value, 10);
    const year = parseInt(yearInput.value, 10);

    if (day < 1 || day > 31 || isNaN(day)) {
        dayError.textContent = 'Day must be between 1 and 31';
        dayInput.classList.add('input-error');
        return false;
    }

    // Check for invalid days in specific months if month is filled out cleanly
    if (!isNaN(month) && month >= 1 && month <= 12) {
        const checkYear = !isNaN(year) ? year : 2024; // Fallback to a safe placeholder leap year if empty
        const maxDays = getDaysInMonth(month, checkYear);
        if (day > maxDays) {
            dayError.textContent = `Day must be between 1 and ${maxDays} for this month`;
            dayInput.classList.add('input-error');
            return false;
        }
    }

    dayError.textContent = '';
    dayInput.classList.remove('input-error');
    return true;
}

// Validates the month input
function validateMonth() {
    if (!monthInput.value.trim()) {
        monthError.textContent = 'Month is required';
        monthInput.classList.add('input-error');
        return false;
    }

    const month = parseInt(monthInput.value, 10);

    if (month < 1 || month > 12 || isNaN(month)) {
        monthError.textContent = 'Month must be between 1 and 12';
        monthInput.classList.add('input-error');
        return false;
    }

    monthError.textContent = '';
    monthInput.classList.remove('input-error');
    return true;
}

// Validates the year input
function validateYear() {
    if (!yearInput.value.trim()) {
        yearError.textContent = 'Year is required';
        yearInput.classList.add('input-error');
        return false;
    }

    const year = parseInt(yearInput.value, 10);
    const currentYear = new Date().getFullYear();

    if (isNaN(year) || year < 1900) {
        yearError.textContent = 'Year must be 1900 or later';
        yearInput.classList.add('input-error');
        return false;
    }

    if (year > currentYear) {
        yearError.textContent = 'Year cannot be in the future';
        yearInput.classList.add('input-error');
        return false;
    }

    yearError.textContent = '';
    yearInput.classList.remove('input-error');
    return true;
}

// Returns the number of days in a given month and year
function getDaysInMonth(month, year) {
    return new Date(year, month, 0).getDate();
}

//Clears all error states across inputs
function clearErrors() {
    dayError.textContent = '';
    monthError.textContent = '';
    yearError.textContent = '';
    generalError.textContent = '';
    
    dayInput.classList.remove('input-error');
    monthInput.classList.remove('input-error');
    yearInput.classList.remove('input-error');
    
    generalError.classList.add('hidden');
}

// Main age calculation engine
function calculateAge() {
    // Force execution of all paths explicitly to prevent validation shortcut skips
    const isDayValid = validateDay();
    const isMonthValid = validateMonth();
    const isYearValid = validateYear();

    if (!isDayValid || !isMonthValid || !isYearValid) {
        resultDiv.classList.add('hidden');
        return;
    }

    const day = parseInt(dayInput.value, 10);
    const month = parseInt(monthInput.value, 10);
    const year = parseInt(yearInput.value, 10);

    const dateOfBirth = new Date(year, month - 1, day);
    const today = new Date();

    if (dateOfBirth > today) {
        generalError.textContent = 'Date of birth cannot be in the future';
        generalError.classList.remove('hidden');
        resultDiv.classList.add('hidden');
        return;
    }

    let years = today.getFullYear() - dateOfBirth.getFullYear();
    let months = today.getMonth() - dateOfBirth.getMonth();
    let days = today.getDate() - dateOfBirth.getDate();

    // Trace negative days boundaries
    if (days < 0) {
        months--;
        const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
        days += lastMonth.getDate();
    }

    // Trace negative months boundaries
    if (months < 0) {
        years--;
        months += 12;
    }

    const totalDays = Math.floor((today - dateOfBirth) / (1000 * 60 * 60 * 24));

    yearsDisplay.textContent = years;
    monthsDisplay.textContent = months;
    daysDisplay.textContent = days;
    totalDaysDisplay.textContent = totalDays;

    resultDiv.classList.remove('hidden');
}